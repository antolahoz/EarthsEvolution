//
//  OnboardingView.swift
//  WWDC24
//
//  Created by Antonio Lahoz on 25/02/24.
//

import SwiftUI

struct OnboardingView: View {
    
    @Binding var shouldShowOnboarding: Bool
    
    var body: some View {
        TabView{
            PageView(title: "Earth's crust",
                     message: "Is the product of a long evolution through continuous transformations",
                     imageName: "globe.europe.africa.fill", 
                     showsDismissButton: false,
                     shouldShowOnboarding: $shouldShowOnboarding)
            PageView(title: "Plate tectonics",
                     message: "This theory bserves the behavior of the lithosphere, which is characterized by very active belts with seismicity and volcanism",
                     imageName: "leaf.fill", 
                     showsDismissButton: false,
                     shouldShowOnboarding: $shouldShowOnboarding)
            PageView(title: "Earth's plate margins",
                     message: "The belts form a network of terrestrial plates, and their edges are called margins",
                     imageName: "wind",
                     showsDismissButton: false,
                     shouldShowOnboarding: $shouldShowOnboarding)
            PageView(title: "Discover the margins!",
                     message: "Discover points of interest where Earth's plate activities are highlighted with this app!",
                     imageName: "play.fill", 
                     showsDismissButton: true,
                     shouldShowOnboarding: $shouldShowOnboarding)
                
            
        }
        .tabViewStyle(PageTabViewStyle())
    }
}



//#Preview {
//    OnboardingView()
//}
