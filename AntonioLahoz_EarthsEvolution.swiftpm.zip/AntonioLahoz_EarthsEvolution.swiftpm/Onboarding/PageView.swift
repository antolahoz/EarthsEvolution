//
//  File.swift
//  
//
//  Created by Antonio Lahoz on 25/02/24.
//

import Foundation
import SwiftUI

struct PageView: View {
    
    let title: String
    let message: String
    let imageName: String
    let showsDismissButton: Bool
    @Binding var shouldShowOnboarding: Bool
    
    var body: some View {
        VStack{
            
            Image(systemName: imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: 150)
                .foregroundStyle(.orange)
                .padding()
            
            Text(title)
                .font(.system(size: 32))
                .padding()
            
            Text(message)
                .font(.system(size: 24))
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding()
            
            if showsDismissButton{
                Button(action: {
                    shouldShowOnboarding.toggle()
                }, label: {
                    Text("Get started")
                        .bold()
                        .foregroundStyle(.white)
                        .frame(width: 200, height: 50)
                        .background(.orange)
                        .cornerRadius(6)
                })
            }
        }
    }
}
