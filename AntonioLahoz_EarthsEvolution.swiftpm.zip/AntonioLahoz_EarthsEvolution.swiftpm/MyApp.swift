import SwiftUI

@main
struct MyApp: App {
    @StateObject var boundary = Boundaries()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(boundary)
        }
    }
}
