//
//  HomeView.swift
//  WWDC24
//
//  Created by Antonio Lahoz on 14/02/24.
//

import SwiftUI
import MapKit

struct ContentView: View {
    
    @AppStorage("shouldShowOnboarding") var shouldShowOnboarding = true
    
    @EnvironmentObject var boundary: Boundaries
    @State var selectedItem: Boundary = .init(location: "", type: "", latitude: 0.0, longitude: 0.0, infos: "")

    @State private var toggler = false
    
    var body: some View {
        
        NavigationStack{
            
            if #available(iOS 17.0, *) {
                
                Map{
                    
                    ForEach(boundary.listOfBoundaries) { boundary in
                        Annotation(boundary.location, coordinate: CLLocationCoordinate2D(latitude: boundary.latitude, longitude: boundary.longitude)) {
                            ZStack {
                                Image(systemName: "mappin.circle.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .onTapGesture {
                                        toggler.toggle()
                                        selectedItem = boundary
                                        
                                    }
                                    .foregroundStyle(.white, .orange)
                                
                            }
                            .sheet(isPresented: $toggler){
                                ItemInfoView(boundary: $selectedItem)
                                
                            }
                        }
                    }
                    
                }
                .mapStyle(.hybrid(elevation: .realistic))
                
            } else {
            }
        }
        .fullScreenCover(isPresented: $shouldShowOnboarding, content: {
                OnboardingView(shouldShowOnboarding: $shouldShowOnboarding)
                .preferredColorScheme(.dark)
            })
    }
}
