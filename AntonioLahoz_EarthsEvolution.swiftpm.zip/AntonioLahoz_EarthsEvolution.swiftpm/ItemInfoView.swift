//
//  ItemInfoView.swift
//  WWDC24
//
//  Created by Antonio Lahoz on 23/02/24.
//

import SwiftUI

struct ItemInfoView: View {

    @Binding var boundary: Boundary
    
    var body: some View {
        
        VStack{
            
                Section{
                    Text(boundary.location)
                        .fontWeight(.bold)
                        .font(.largeTitle)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.orange)
                }
            VStack(spacing: 10){

                Section{
                    Text(boundary.type)
                        .fontWeight(.semibold)
                }
                
                Section{
                    Text(boundary.infos)
                }
            }
        }
    }
}

#Preview {
    
    @State var boundary: Boundary = .init(location: "", type: "", latitude: 0.0, longitude: 0.0, infos: "")
    
    return ItemInfoView(boundary: $boundary)
}

