//
//  Location.swift
//  WWDC24
//
//  Created by Antonio Lahoz on 21/02/24.
//

import Foundation

struct Boundary: Identifiable, Equatable {
    
    init(id: UUID = UUID(), location: String, type: String, latitude: Double, longitude: Double, infos: String) {
        self.id = id
        self.location = location
        self.type = type
        self.latitude = latitude
        self.longitude = longitude
        self.infos = infos
    }
    
    var id = UUID()
    var location: String
    var type: String
    var latitude: Double
    var longitude: Double
    
    var infos: String
}
