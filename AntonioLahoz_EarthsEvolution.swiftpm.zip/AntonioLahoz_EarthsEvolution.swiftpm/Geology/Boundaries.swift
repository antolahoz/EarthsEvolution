//
//  File.swift
//  
//
//  Created by Antonio Lahoz on 23/02/24.
//

import Foundation

class Boundaries: ObservableObject{
    
    @Published var listOfBoundaries = [
        Boundary(location: "The San Andreas Fault", type: "Transform boundary", latitude: 35.116664, longitude: -119.649997, infos: """
Here we have transform faults, along which two plates flow side by side in opposite directions.

They are manifested by metamorphism and strong seismic activity.

They are also called "conservative", because neither destroys nor produces Earth's crust.
"""),
        
        Boundary(location: "The Alpide Belt", type: "Convergent boundary", latitude: 46.77367, longitude: 10.54773, infos: """
Here we have convergent, or also called destructive, margins between two continental crusts.

The plates move against each other, and here we have the phenomenon of orogenesis, which explains the formation of mountains.
"""
),
        
        Boundary(location: "The Mariana Trench", type: "Convergent boundary", latitude: 11.3493, longitude: 142.1996, infos: """
Here we have convergent, or also called destructive, margins between two oceanic crusts.

The plates move against each other, and in this case we have the phenomenon of oceanic trenches.
"""),
        
        Boundary(location: "The Atacama Trench - The Andes Mountain Range", type: "Convergent boundary", latitude: -19.466054, longitude: -70.254883, infos: """
Here we have convergent, or also called destructive, margins between oceanic crust and continental crust.

The plates move against each other, and here we have the phenomenon of subduction: the oceanic crust plunges into the continental crust through a subduction plane, releasing magma.

There could be a possible formation of volcanoes.
"""),
        
        Boundary(location: "Atlantic Ocean", type: "Divergent boundary", latitude: 17.672289, longitude: -36.507807, infos: """
Here we have divergent, or also called constructive, margins between two oceanic crusts.

The plates move away from each other and new crust is produced.

Here we have the formation of mid-ocean ridges, ridges in which the oceanic crust is arched upward, and there is a possible formation of volcanic islands.
"""),
        
        Boundary(location: "Great Rift Valley", type: "Divergent boundary", latitude: 11.4099, longitude: 41.2809, infos: """
Here we have divergent, or also called constructive, margins between two continental crusts.

The plates move away from each other and new crust is produced.

In this case we can have the Horst Graben phenomenon: between two Graben, sunken portions of crust, an area of uplifted Earth's crust, called Horst, can be distinguished.
""")
    ]
}
